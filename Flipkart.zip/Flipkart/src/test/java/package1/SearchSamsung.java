package package1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class SearchSamsung
{
	public static WebDriver driver=null;
	public String mobileSearch,x1sourcepath,x1resultpath,url;
	public String mobile1,mobile2,mobile3,mobile4,mobile5,mobile6,mobile7,mobile8,mobile9;
	public String price1,price2,price3,price4,price5,price6,price7,price8,price9;
	public String xTD[][];
	public int xRows,xCols;
	
	
	@Test(priority=1)
	public void initialization() throws Exception 
	{
		x1sourcepath = "D:\\Java Projects\\Flipkart\\src\\test\\resources\\readexcel1\\Book1.xls";
		x1resultpath = "D:\\Java Projects\\Flipkart\\src\\test\\resources\\writeexcel1\\Book2.xls";
		xTD=readXL(x1sourcepath,"TestData");

	}
	
	@Test(priority=2)
	public void searchmobile() throws InterruptedException, IOException
	{
		int i=1;	
			mobileSearch = xTD[i][0];
			url = "https://www.flipkart.com";
			
			System.setProperty("webdriver.chrome.driver","D:\\Java Projects\\Flipkart\\src\\test\\resources\\browserexe\\chromedriver.exe");
			driver = new ChromeDriver();
			
			driver.get(url);
			
			driver.manage().window().maximize();
			
			
			driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
			
			getScreenshots("D:\\Java Projects\\Flipkart\\src\\test\\resources\\scnshots\\screenshot1.png");
			
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			
			driver.findElement(By.cssSelector("input.LM6RPg")).sendKeys(mobileSearch);
			
			getScreenshots("D:\\Java Projects\\Flipkart\\src\\test\\resources\\scnshots\\screenshot2.png");
			
			driver.findElement(By.xpath(".//*[@id='container']/div/div[1]/div[1]/div[2]/div[2]/form/div/button")).click();
			
			WebElement dd = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div[1]/div[1]/div/div[1]/div/section[2]/div[4]/div[3]/select"));
			Select se = new Select(dd);
			se.selectByValue("10000");
			
			getScreenshots("D:\\Java Projects\\Flipkart\\src\\test\\resources\\scnshots\\screenshot3.png");
			
			Thread.sleep(3000);
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,500)");
			
			driver.findElement(By.xpath("//*[text()='2 GB']")).click();
			
			getScreenshots("D:\\Java Projects\\Flipkart\\src\\test\\resources\\scnshots\\screenshot4.png");
			
			Thread.sleep(4000);
		
			js.executeScript("window.scrollBy(0,1500)");
			
			Thread.sleep(4000);
			
			driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div[1]/div[1]/div/div[1]/div/section[16]/div/div")).click();
			getScreenshots("D:\\Java Projects\\Flipkart\\src\\test\\resources\\scnshots\\screenshot5.png");
			Thread.sleep(2000);
			
			driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div[1]/div[1]/div/div[1]/div/section[16]/div[2]/div/div[3]/div/div/label/div[2]")).click();
		
			getScreenshots("D:\\Java Projects\\Flipkart\\src\\test\\resources\\scnshots\\screenshot6.png");
			
			mobile1 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][1] = mobile1;
			mobile2 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[3]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][2] = mobile2;
			mobile3 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[4]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][3] = mobile3;
			mobile4 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[5]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][4] = mobile4;
			mobile5 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[6]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][5] = mobile5;
			mobile6 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[7]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][6] = mobile6;
			mobile7 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[8]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][7] = mobile7;
			mobile8 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[9]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][8] = mobile8;
			mobile9 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[10]/div/div/div/a/div[2]/div[1]/div[1]")).getText();
			xTD[i][9] = mobile9;
		
			price1 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][1] = price1;
			price2 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[3]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][2] = price2;
			price3 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[4]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][3] = price3;
			price4 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[5]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][4] = price4;
			price5 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[6]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][5] = price5;
			price6 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[7]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][6] = price6;
			price7 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[8]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][7] = price7;
			price8 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[9]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][8] = price8;
			price9 = driver.findElement(By.xpath(".//*[@id='container']/div/div[3]/div[2]/div/div[2]/div[10]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText();
			xTD[2][9] = price9;
	
		
		
		
		
	}
	
	@Test(priority=3)
	public void tearDown() throws Exception
	{
		writeXL(x1resultpath, "Sheet1", xTD);
	}
	
	
	//For Reading Excel
	public String[][] readXL(String fPath, String fSheet) throws Exception
	{
		// Inputs : XL Path and XL Sheet name

		
			String[][] xData;   

			File myxl = new File(fPath);   
			
			FileInputStream myStream = new FileInputStream(myxl);  
			
			HSSFWorkbook myWB = new HSSFWorkbook(myStream);  
			
			HSSFSheet mySheet = myWB.getSheet(fSheet);                                 
			xRows = mySheet.getLastRowNum()+1;                                
			xCols = mySheet.getRow(0).getLastCellNum();   
			System.out.println("Total Rows in Excel are " + xRows);
			System.out.println("Total Cols in Excel are " + xCols);
			xData = new String[xRows][xCols];        
			for (int i = 0; i < xRows; i++) {                           
					HSSFRow row = mySheet.getRow(i);
					for (int j = 0; j < xCols; j++) {                               
						HSSFCell cell = row.getCell(j);
						String value = "-";
						if (cell!=null){
						value = cellToString(cell);
						
						}
						xData[i][j] = value;      
						System.out.print(value);
						System.out.print("----");
						}        
					System.out.println("");
					}    
			myxl = null; // Memory gets released
			return xData;
	}
	
	
	public static String cellToString(HSSFCell cell) 
	{ 
		// This function will convert an object of type excel cell to a string value
		int type = cell.getCellType();                        
		Object result;                        
		switch (type) {                            
			case HSSFCell.CELL_TYPE_NUMERIC: //0                                
				result = cell.getNumericCellValue();                                
				break;                            
			case HSSFCell.CELL_TYPE_STRING: //1                                
				result = cell.getStringCellValue();                                
				break;                            
			case HSSFCell.CELL_TYPE_FORMULA: //2                                
				throw new RuntimeException("We can't evaluate formulas in Java");  
			case HSSFCell.CELL_TYPE_BLANK: //3                                
				result = "%";                                
				break;                            
			case HSSFCell.CELL_TYPE_BOOLEAN: //4     
				result = cell.getBooleanCellValue();       
				break;                            
			case HSSFCell.CELL_TYPE_ERROR: //5       
				throw new RuntimeException ("This cell has an error");    
			default:                  
				throw new RuntimeException("We don't support this cell type: " + type); 
				}                        
		return result.toString();      
		}
	
	
	// Method to write into an XL
		public void writeXL(String fPath, String fSheet, String[][] xData) throws Exception
		{

		    	File outFile = new File(fPath);
		        HSSFWorkbook wb = new HSSFWorkbook();
		        HSSFSheet osheet = wb.createSheet(fSheet);
		        int xR_TS = xData.length;
		        int xC_TS = xData[0].length;
		    	for (int myrow = 0; myrow < xR_TS; myrow++) 
		    	{
			        HSSFRow row = osheet.createRow(myrow);
			        for (int mycol = 0; mycol < xC_TS; mycol++) 
			        {
			        	HSSFCell cell = row.createCell(mycol);
			        	cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			        	cell.setCellValue(xData[myrow][mycol]);
			        }
			        FileOutputStream fOut = new FileOutputStream(outFile);
			        wb.write(fOut);
			        fOut.flush();
			        fOut.close();
		    	}
			}
		
		
		public static void getScreenshots(String path) throws IOException
		{
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(path));
		
		}
}


